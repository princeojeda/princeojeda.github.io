/*
 * Only upto 2147483647 
 * 
 * Name: Ojeda, Prince Jeorge V.
 * 
 */

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.Font;
import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;

class Calculator {
    JFrame window;
    JPanel panel, displayPanel;
    JTextField display;
    JButton[] numberBTNs;
    JButton[] operationBTNs;

    boolean replace = false;

    Font font;

    Calculator() {
        window = new JFrame();
        window.setTitle("Simple Calculator");
        window.setSize(400, 600);
        window.setIconImage(new ImageIcon("assets/icons/logo.png").getImage());
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        if (screenSize.width < 400 || screenSize.height < 600) {
            window.setSize(screenSize.width, screenSize.height);
        }
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setLayout(new GridBagLayout());
        window.setLocationRelativeTo(null);
        window.setAutoRequestFocus(true);
        window.setResizable(false);

        try {
            font = Font.createFont(Font.TRUETYPE_FONT, new File("assets/font/visitor1.ttf")).deriveFont(30f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(font);
        } catch (Exception e) {
            e.printStackTrace();
        }

        panel = new JPanel();
        panel.setLayout(new GridLayout(4, 4));
        panel.setFocusable(false);

        displayPanel = new JPanel();
        displayPanel.setPreferredSize(new Dimension(380, 100));
        displayPanel.setLayout(new GridBagLayout());
        displayPanel.setFocusable(false);
        displayPanel.setBorder(null);

        display = new JTextField();
        display.setText("0");
        display.setFont(font);
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setEditable(false);
        display.setFocusable(false);
        display.setBorder(null);
        display.setBackground(Color.WHITE);

        JButton clear = new JButton("C");
        clear.setPreferredSize(new Dimension(70, 100));
        clear.setBackground(Color.WHITE);
        clear.setForeground(Color.decode("#FC8619"));
        clear.setFont(font);

        clear.setBorder(null);

        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                display.setText("0");
            }
        });
        clear.setFocusable(false);

        JButton backspace = new JButton();
        ImageIcon icon = new ImageIcon("assets/icons/icons8-backspace-24.png");
        backspace.setIcon(icon);
        backspace.setPreferredSize(new Dimension(70, 100));
        backspace.setBackground(Color.WHITE);
        backspace.setForeground(Color.BLACK);
        backspace.setBorder(null);
        backspace.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                String text = display.getText();
                if (text.length() > 0) {
                    display.setText(text.substring(0, text.length() - 1));
                }
                if (text.length() == 1) {
                    display.setText("0");
                }
            }
        });
        backspace.setFocusable(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridy = 0;
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.VERTICAL;
        displayPanel.add(clear, gbc);
        gbc.gridx = 2;
        displayPanel.add(backspace, gbc);

        gbc.gridx = 0;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.BOTH;
        displayPanel.add(display, gbc);

        String btnValue = "789/456*123-0.=+";
        JButton[] buttons = new JButton[16];
        for (int i = 0; i < 16; i++) {
            buttons[i] = new JButton();
            buttons[i].setName(btnValue.substring(i, i + 1));
            switch (i) {
                case 3:
                    icon = new ImageIcon("assets/icons/a.png");
                    buttons[i].setIcon(icon);
                    break;

                case 7:
                    icon = new ImageIcon("assets/icons/b.png");
                    buttons[i].setIcon(icon);
                    break;

                case 11:
                    icon = new ImageIcon("assets/icons/c.png");
                    buttons[i].setIcon(icon);
                    break;

                case 15:
                    icon = new ImageIcon("assets/icons/d.png");
                    buttons[i].setIcon(icon);
                    break;

                case 14:
                    icon = new ImageIcon("assets/icons/e.png");
                    buttons[i].setIcon(icon);
                    break;

                default:
                    buttons[i].setText(btnValue.substring(i, i + 1));
                    break;
            }
            buttons[i].setFont(font);
            buttons[i].setPreferredSize(new Dimension(70, 70));

            buttons[i].setBackground(Color.WHITE);
            buttons[i].setForeground(Color.BLACK);

            buttons[i].setBorder(null);

            buttons[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(java.awt.event.ActionEvent e) {
                    JButton btn = (JButton) e.getSource();
                    if (btn.getName().equals("=")) {
                        String result = compute(display.getText());
                        replace = true;
                        try {
                            if (Double.parseDouble(result) % 1 == 0) {
                                display.setText(String.valueOf((int) Double.parseDouble(result)));
                            } else {
                                display.setText(result);
                            }
                        } catch (Exception e1) {
                            popup(result);
                            display.setText(result);
                        }
                    } else {
                        String text = display.getText();
                        if (((replace || text.equals("0")) && btn.getName().matches("[0-9.]"))
                                || text.equals("can't divide by zero")) {
                            text = "";
                            replace = false;
                        } else {
                            replace = false;
                        }
                        if (text.matches(".*[/*+\\-.]$") && btn.getName().matches(".*[/*+\\-]$")) {
                            if (text.length() == 0) {
                                return;
                            }
                            display.setText(text.substring(0, text.length() - 1) + btn.getName());
                        } else {
                            String[] nums = text.split("[/*+\\-]");
                            if (nums.length >= 1) {
                                if (btn.getName().equals(".")) {
                                    if (text.isEmpty()) {
                                        display.setText(text + "0" + btn.getName());
                                        return;
                                    }
                                    if (text.matches(".*[/*+\\-]$")) {
                                        display.setText(text + "0" + btn.getName());
                                        return;
                                    }
                                    if (nums[nums.length - 1].contains(".")) {
                                        return;
                                    }
                                }
                            }

                            if (text.isEmpty() && btn.getName().matches("[/*]")) {
                                display.setText("0" + btn.getName());
                                return;
                            }
                            if (text.isEmpty() && (btn.getName().equals("-") || btn.getName().equals("+"))) {
                                display.setText("0" + btn.getName());
                                return;
                            }
                            display.setText(text + btn.getName());
                        }
                    }
                }
            });
            buttons[i].setFocusable(false);

            panel.add(buttons[i]);
        }

        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.BOTH;
        window.add(displayPanel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weighty = 1;
        window.add(panel, gbc);

        KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(new KeyEventDispatcher() {
            @Override
            public boolean dispatchKeyEvent(KeyEvent e) {
                if (e.getID() == KeyEvent.KEY_TYPED) {
                    char key = e.getKeyChar();
                    if (key == '\n') {
                        String result = compute(display.getText());
                        replace = true;
                        try {
                            if (Double.parseDouble(result) % 1 == 0) {
                                display.setText(String.valueOf((int) Double.parseDouble(result)));
                            } else {
                                display.setText(String.valueOf(result));
                            }
                        } catch (Exception e1) {
                            popup(result);
                            display.setText(result);
                        }
                    } else {
                        String text = display.getText();
                        if (((replace || text.equals("0")) && String.valueOf(key).matches("[0-9.]"))
                                || text.equals("can't divide by zero")) {
                            text = "";
                            replace = false;
                        } else {
                            replace = false;
                        }
                        if (text.matches(".*[/*+\\-.]$") && String.valueOf(key).matches(".*[/*+\\-]$")) {
                            if (text.length() == 0) {
                                return false;
                            }
                            display.setText(text.substring(0, text.length() - 1) + key);
                        } else if (String.valueOf(key).matches("[0-9./*+\\-]")) {
                            String[] nums = text.split("[/*+\\-]");
                            if (nums.length >= 1) {
                                if (key == '.') {
                                    if (text.isEmpty()) {
                                        display.setText(text + "0" + key);
                                        return false;
                                    }
                                    if (text.matches(".*[/*+\\-]$")) {
                                        display.setText(text + "0" + key);
                                        return false;
                                    }
                                    if (nums[nums.length - 1].contains(".")) {
                                        return false;
                                    }
                                }
                            }

                            if (text.isEmpty() && String.valueOf(key).matches("[/*]")) {
                                display.setText("0" + key);
                                return false;
                            }
                            if (text.isEmpty() && (key == '-' || key == '+')) {
                                display.setText("0" + key);
                                return false;
                            }
                            display.setText(text + key);
                        }
                        if (key == '\b') {
                            if (text.length() > 0) {
                                display.setText(text.substring(0, text.length() - 1));
                            }
                            if (text.length() == 1) {
                                display.setText("0");
                            }
                        } else if (key == 'c' || key == 'C') {
                            display.setText("0");
                        }
                    }
                }
                return false;
            }
        });

    }

    void show() {
        window.setVisible(true);
    }

    String compute(String expression) {

        String[] numbers = expression.split("(?<=[0-9])[/*+\\-](?=[0-9])");
        String[] operators = expression.substring(1).split("[0-9.]+");
        ArrayList<String> ops = new ArrayList<>();
        for (String operator : operators) {
            if (operator.length() > 0) {
                ops.add(operator);
            }
        }

        String[] newOps = new String[ops.size()];
        for (int i = 0; i < ops.size(); i++) {
            newOps[i] = ops.get(i);
        }

        BigDecimal[] nums = new BigDecimal[numbers.length];
        for (int i = 0; i < numbers.length; i++) {
            try {
                nums[i] = new BigDecimal(numbers[i]);
            } catch (NumberFormatException e) {
                nums[i] = new BigDecimal(
                        numbers[i].replace(e.getMessage().split("Character")[1].split("is")[0].strip(), ""));
            }
        }

        ArrayList<Object> list = new ArrayList<>();
        for (int i = 0; i < nums.length; i++) {
            list.add(nums[i]);
            if (i < newOps.length) {
                list.add(newOps[i]);
            }
        }
        int odd = 1;
        for (String op : newOps) {
            list.set(odd, op);
            odd += 2;
        }

        BigDecimal result = BigDecimal.ZERO;

        Object[] mdas = { "*", "/", "+", "-" };

        if (Arrays.asList(mdas).contains(list.get(list.size() - 1))) {
            list.remove(list.size() - 1);
        }

        while (list.size() != 1) {
            int index = 0;
            if ((list.contains("*") || list.contains("/")) && (list.contains("+") || list.contains("-"))) {
                for (Object mda : mdas) {
                    while (list.contains(mda)) {
                        index = list.indexOf(mda);
                        BigDecimal num1 = (BigDecimal) list.get(index - 1);
                        BigDecimal num2 = (BigDecimal) list.get(index + 1);
                        BigDecimal res = BigDecimal.ZERO;
                        switch ((String) mda) {
                            case "*":
                                res = num1.multiply(num2);
                                break;
                            case "/":
                                if (num2.equals(BigDecimal.ZERO)) {
                                    return "can't divide by zero";
                                }
                                res = num1.divide(num2, 10, RoundingMode.HALF_UP);
                                break;
                            case "+":
                                res = num1.add(num2);
                                break;
                            case "-":
                                res = num1.subtract(num2);
                                break;
                        }
                        list.set(index - 1, res);
                        list.remove(index);
                        list.remove(index);
                    }
                }
            } else {
                result = (BigDecimal) list.get(0);
                for (int i = 1; i < list.size() - 1; i += 2) {
                    BigDecimal num = (BigDecimal) list.get(i + 1);
                    switch ((String) list.get(i)) {
                        case "*":
                            result = result.multiply(num);
                            break;
                        case "/":
                            if (num.equals(BigDecimal.ZERO)) {
                                return "can't divide by zero";
                            }
                            result = result.divide(num, 10, RoundingMode.HALF_UP);
                            break;
                        case "+":
                            result = result.add(num);
                            break;
                        case "-":
                            result = result.subtract(num);
                            break;
                    }
                    list.set(0, result);
                    list.remove(i);
                    list.remove(i);
                }
            }
        }

        result = (BigDecimal) list.get(0);

        return String.valueOf(Double.parseDouble(result.toString()));
    }

    void popup(String message) {
        JOptionPane.showMessageDialog(window, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

}

public class Main {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        calculator.show();
    }
}
